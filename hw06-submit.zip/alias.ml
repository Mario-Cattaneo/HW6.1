(** Alias Analysis *)

open Ll
open Datastructures

(* The lattice of abstract pointers ----------------------------------------- *)
module SymPtr =
  struct
    type t = MayAlias           (* uid names a pointer that may be aliased *)
           | Unique             (* uid is the unique name for a pointer *)
           | UndefAlias         (* uid is not in scope or not a pointer *)

    let compare : t -> t -> int = Pervasives.compare

    let to_string = function
      | MayAlias -> "MayAlias"
      | Unique -> "Unique"
      | UndefAlias -> "UndefAlias"

  end

(* The analysis computes, at each program point, which UIDs in scope are a unique name
   for a stack slot and which may have aliases *)
type fact = SymPtr.t UidM.t

(* flow function across Ll instructions ------------------------------------- *)
(* TASK: complete the flow function for alias analysis. 

   - After an alloca, the defined UID is the unique name for a stack slot
   - A pointer returned by a load, call, bitcast, or GEP may be aliased
   - A pointer passed as an argument to a call, bitcast, GEP, or store
     may be aliased
   - Other instructions do not define pointers

 *)
let insn_flow ((u,i):uid * insn) (d:fact) : fact =
  let is_ptr_ty = function
    | Ptr _ -> true
    | _ -> false
  in
  let mark_may_alias_uid (m:fact) (uid:uid) : fact =
    UidM.add uid SymPtr.MayAlias m
  in
  (* First, account for operands that, when used, may become aliased. *)
  let d =
    match i with
    | Load (_, op) ->
        (* Pointer being loaded from may now be aliased. *)
        begin match op with
        | Id p -> mark_may_alias_uid d p
        | _ -> d
        end
    | Store (_, src, dst) ->
        (* Both the stored pointer and the destination pointer may be aliased. *)
        let d =
          match src with
          | Id p -> mark_may_alias_uid d p
          | _ -> d
        in
        begin match dst with
        | Id p -> mark_may_alias_uid d p
        | _ -> d
        end
    | Call (_, _, args) ->
        (* Any pointer argument to a call may be aliased. *)
        List.fold_left
          (fun m (t, o) ->
             match t, o with
             | Ptr _, Id p -> mark_may_alias_uid m p
             | _ , _ -> m)
          d args
    | Bitcast (_, op, _) ->
        (* Pointer argument to bitcast may be aliased. *)
        begin match op with
        | Id p -> mark_may_alias_uid d p
        | _ -> d
        end
    | Gep (_, base, _) ->
        (* Base pointer to gep may be aliased. *)
        begin match base with
        | Id p -> mark_may_alias_uid d p
        | _ -> d
        end
    | _ -> d
  in
  (* Then, account for the value defined by this instruction, if any. *)
  match i with
  | Alloca _ ->
      (* Allocas are unique stack slots. *)
      UidM.add u SymPtr.Unique d
  | Load (t, _) ->
      if is_ptr_ty t
      then UidM.add u SymPtr.MayAlias d
      else UidM.add u SymPtr.UndefAlias d
  | Call (t, _, _) ->
      if is_ptr_ty t
      then UidM.add u SymPtr.MayAlias d
      else UidM.add u SymPtr.UndefAlias d
  | Bitcast (_, _, t') ->
      if is_ptr_ty t'
      then UidM.add u SymPtr.MayAlias d
      else UidM.add u SymPtr.UndefAlias d
  | Gep (t, _, _) ->
      (* Result of GEP is always a pointer. *)
      if is_ptr_ty t
      then UidM.add u SymPtr.MayAlias d
      else UidM.add u SymPtr.UndefAlias d
  | _ ->
      (* Other instructions do not define pointers. *)
      UidM.add u SymPtr.UndefAlias d


(* The flow function across terminators is trivial: they never change alias info *)
let terminator_flow t (d:fact) : fact = d

(* module for instantiating the generic framework --------------------------- *)
module Fact =
  struct
    type t = fact
    let forwards = true

    let insn_flow = insn_flow
    let terminator_flow = terminator_flow
    
    (* UndefAlias is logically the same as not having a mapping in the fact. To
       compare dataflow facts, we first remove all of these *)
    let normalize : fact -> fact = 
      UidM.filter (fun _ v -> v != SymPtr.UndefAlias)

    let compare (d:fact) (e:fact) : int = 
      UidM.compare SymPtr.compare (normalize d) (normalize e)

    let to_string : fact -> string =
      UidM.to_string (fun _ v -> SymPtr.to_string v)

    (* TASK: complete the "combine" operation for alias analysis.

       The alias analysis should take the join over predecessors to compute the
       flow into a node. You may find the UidM.merge function useful.

       It may be useful to define a helper function that knows how to take the
       join of two SymPtr.t facts.
    *)
    let combine (ds:fact list) : fact =
      let join_sym (a:SymPtr.t) (b:SymPtr.t) : SymPtr.t =
        match a, b with
        | UndefAlias, x
        | x, UndefAlias -> x
        | Unique, Unique -> Unique
        | MayAlias, _
        | _, MayAlias -> MayAlias
      in
      let join_maps (m1:fact) (m2:fact) : fact =
        UidM.merge
          (fun _ v1 v2 ->
             match v1, v2 with
             | None, None -> None
             | Some x, None
             | None, Some x -> Some x
             | Some x, Some y ->
                 let r = join_sym x y in
                 if r = SymPtr.UndefAlias then None else Some r)
          m1 m2
      in
      match ds with
      | [] -> UidM.empty
      | d::rest -> List.fold_left join_maps d rest
  end

(* instantiate the general framework ---------------------------------------- *)
module Graph = Cfg.AsGraph (Fact)
module Solver = Solver.Make (Fact) (Graph)

(* expose a top-level analysis operation ------------------------------------ *)
let analyze (g:Cfg.t) : Graph.t =
  (* the analysis starts with every node set to bottom (the map of every uid 
     in the function to UndefAlias *)
  let init l = UidM.empty in

  (* the flow into the entry node should indicate that any pointer parameter 
     to the function may be aliased *)
  let alias_in = 
    List.fold_right 
      (fun (u,t) -> match t with
                    | Ptr _ -> UidM.add u SymPtr.MayAlias
                    | _ -> fun m -> m) 
      g.Cfg.args UidM.empty 
  in
  let fg = Graph.of_cfg init alias_in g in
  Solver.solve fg

