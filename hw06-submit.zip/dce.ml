(** Dead Code Elimination  *)
open Ll
open Datastructures


(* expose a top-level analysis operation ------------------------------------ *)
(* TASK: This function should optimize a block by removing dead instructions
   - lb: a function from uids to the live-OUT set at the 
     corresponding program point
   - ab: the alias map flowing IN to each program point in the block
   - b: the current ll block

   Note: 
     Call instructions are never considered to be dead (they might produce
     side effects)

     Store instructions are not dead if the pointer written to is live _or_
     the pointer written to may be aliased.

     Other instructions are dead if the value they compute is not live.

   Hint: Consider using List.filter
 *)
let dce_block (lb:uid -> Liveness.Fact.t) 
              (ab:uid -> Alias.fact)
              (b:Ll.block) : Ll.block =
  let open Liveness in
  let open Alias in
  let is_live (live_out:Liveness.Fact.t) (u:uid) : bool =
    UidS.mem u live_out
  in
  let keep_insn ((u,i) : uid * insn) : bool =
    match i with
    | Call _ ->
        (* Calls are never considered dead (possible side effects). *)
        true
    | Store (_, _, dst) ->
        (* A store is dead only if the destination pointer is unique and not live. *)
        begin match dst with
        | Id p ->
            let live_out = lb u in
            let aliases = ab u in
            let alias_info =
              UidM.find_or SymPtr.UndefAlias aliases p
            in
            let ptr_live = is_live live_out p in
            (* Remove store if pointer is unique and not live-out. *)
            not (not ptr_live && alias_info = SymPtr.Unique)
        | _ ->
            (* Can't reason about non-uid destinations; keep conservatively. *)
            true
        end
    | _ ->
        (* Other instructions are dead if the uid they define is not live-out. *)
        let live_out = lb u in
        is_live live_out u
  in
  let insns' = List.filter keep_insn b.insns in
  { b with insns = insns' }

let run (lg:Liveness.Graph.t) (ag:Alias.Graph.t) (cfg:Cfg.t) : Cfg.t =

  LblS.fold (fun l cfg ->
    let b = Cfg.block cfg l in

    (* compute liveness at each program point for the block *)
    let lb = Liveness.Graph.uid_out lg l in

    (* compute aliases at each program point for the block *)
    let ab = Alias.Graph.uid_in ag l in 

    (* compute optimized block *)
    let b' = dce_block lb ab b in
    Cfg.add_block l b' cfg
  ) (Cfg.nodes cfg) cfg

